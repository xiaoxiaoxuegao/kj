===========================
How to Use Grunt with Basic
===========================

Grunt requires Node.JS to be installed on your machine. There are various
package managers that can handle this for you.

https://nodejs.org/download/

Once Node.JS is installed, go to basic/grunt and install your grunt packages:

  npm install

This will install the neccissary node_modules to run grunt. Once installed, run
grunt via the command line:

  grunt

This will initialize grunt and start watching changes to your SASS files. Voila!