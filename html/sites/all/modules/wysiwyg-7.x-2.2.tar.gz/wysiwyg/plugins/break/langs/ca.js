
tinyMCE.addToLang('break', {
  title: 'Inserir marcador de document retallat',
  desc: 'Generar el punt de separació entre la versió retallada del document i la resta del contingut'
});

